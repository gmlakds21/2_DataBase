create definer = rdsadmin@localhost trigger block_event_d
    before delete
    on event
    for each row
BEGIN
    if old.Definer = 'rdsadmin@localhost' then
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'CANNOT DROP RDSADMIN OBJECT';
    end if;
END;

