create
    definer = rdsadmin@localhost procedure rds_kill(IN thread bigint)
BEGIN
  DECLARE l_user varchar(16);
  DECLARE l_host varchar(64);
  DECLARE foo varchar(255);

  SELECT user, host INTO l_user, l_host
  FROM information_schema.processlist
  WHERE id = thread;

  IF l_user = "rdsadmin" and l_host like "localhost%" THEN
    select `ERROR (RDS): CANNOT KILL RDSADMIN SESSION` into foo;
  ELSEIF l_user = "rdsrepladmin" THEN
    select `ERROR (RDS): CANNOT KILL RDSREPLADMIN SESSION` into foo;
  ELSE
    KILL thread;
  END IF;
END;

